/**
�y�@�Z���J�S�X�@�z

  PERIDOT LCD Edition
  ��ʏ��Procyon�J�[����]

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <system.h>
#include <io.h>

#include "mmcfs/mmcfs.h"

#include "nd_lib/nd_egl.h"
#include "nd_lib/ILI9325.h"
#include "nd_lib/nd_object.h"
#include "nd_lib/nd_texture.h"
#include "nd_lib/def_car.h"


#define BG_COLOR			set_pixel(120,120,128)	//nd_pixelcolor(120,120,128)

nd_info_workframe WorkFrame;
nd_u8 j7work[nd_J7SYS_WORKAREA_SIZE(2000,2000,10*1024)];

nd_info_model id_carshadow;
nd_info_model id_cartire[4];
nd_info_model id_carbody;

nd_u32 geotime,rendtime;


/* ���f���ƃe�N�X�`���������� */
void model_init(void)
{
	int i;

//	i= nd_GsTextureSet(carbody.h.pTextop->pTexdata);

	// �{�f�B 
	nd_GsTextableRegist(carbody.h.pTextop);
	nd_GsInitModel(&id_carbody);
	id_carbody.attr     = nd_model_on;
	id_carbody.pNearObj = &(carbody.t);

//	nd_GsTextureRemove(i);

	// �^�C�� 
	nd_GsTextableRegist(cartire.h.pTextop);

	for(i=0 ; i<4 ; i++) {
		nd_GsInitModel(&id_cartire[i]);
		id_cartire[i].attr     = nd_model_on;
		id_cartire[i].pNearObj = &(cartire.t);
		id_cartire[i].pUp      = &id_carbody;
		id_cartire[i].zoffs    = cartire_zoffset;
		id_cartire[i].tex_yadj = 72 << 12;
	}

	id_cartire[0].x  = cartire_fl_offx;		// ���t�����g 
	id_cartire[0].y  = cartire_fl_offy;
	id_cartire[0].z  = cartire_fl_offz;
	id_cartire[0].ry = 0;
	id_cartire[0].rz = cartire_fl_rz;

	id_cartire[1].x  = cartire_fr_offx;		// �E�t�����g 
	id_cartire[1].y  = cartire_fr_offy;
	id_cartire[1].z  = cartire_fr_offz;
	id_cartire[1].ry = 0;
	id_cartire[1].rz = cartire_fr_rz;

	id_cartire[2].x  = cartire_rl_offx;		// �����A 
	id_cartire[2].y  = cartire_rl_offy;
	id_cartire[2].z  = cartire_rl_offz;
	id_cartire[2].rz = cartire_rl_rz;

	id_cartire[3].x  = cartire_rr_offx;		// �E���A 
	id_cartire[3].y  = cartire_rr_offy;
	id_cartire[3].z  = cartire_rr_offz;
	id_cartire[3].rz = cartire_rr_rz;

	// �ԑ̂̉e 
	nd_GsInitModel(&id_carshadow);
	id_carshadow.attr     = nd_model_on;
	id_carshadow.pNearObj = &(carshadow.t);
	id_carshadow.pUp      = &id_carbody;
	id_carshadow.zoffs    = carshadow_zoffset;

/*
	// ���H�̐ݒ� 
	nd_GsSetTexture(road.t.pTexture, load_tex_base + 512);
	for(i=0 ; i<4 ; i++) {
		nd_GsInitModel(&id_road[i]);
		id_road[i].attr     = nd_model_on;
		id_road[i].lod_near = 8000;
		id_road[i].pNearObj = &(road_lod1.t);
		id_road[i].pMidObj  = &(road_lod2.t);
		id_road[i].zoffs    = 8000;

		id_road[i].z        = i*7200 - 7200;
		id_road[i].mx       = 9.0 * 4096;
		id_road[i].my       = 9.0 * 4096;
		id_road[i].mz       = 9.0 * 4096;
	}
*/

}

/* ���[�N���[�^�\�� */
void draw_workmeter(void)
{
	nd_s32 i,j,k;
	const int frc_clk = ALT_CPU_FREQ;
	const int div = 14;
	const int v1 = (1 * frc_clk / 60) >> div;
	const int v2 = (2 * frc_clk / 60) >> div;
	const int v3 = (3 * frc_clk / 60) >> div;
	const int v4 = (4 * frc_clk / 60) >> div;

	j = 16;			// �`��J�n�ʒu 

	nd_GsEglColor(nd_COLORWHITE, 0, 256);
	nd_GsEglLine(j,8, j,16);
	nd_GsEglLine(j+v1,8, j+v1,14);
	nd_GsEglLine(j+v2,8, j+v2,14);
	nd_GsEglLine(j+v3,8, j+v3,14);
	nd_GsEglLine(j+v4,8, j+v4,14);

	i = geotime >> div;
	nd_GsEglColor(nd_COLORGREEN, 0, 256);
	nd_GsEglBoxfill(j,10, i,13);				// �W�I���g���S�̂̏������� 

	k = j + (nd_GsVertexGeoTime >> div);
	nd_GsEglColor(nd_COLORBLUE, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);				// ���W�ϊ� 

	j = (++k);
	k = j + (nd_GsVertexPersTime >> div);
	nd_GsEglColor(nd_COLORSKY, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);				// �p�[�X�ϊ� 

	j = (++k);
	k = j + (nd_GsNormalCalcTime >> div);		// �P�x�v�Z 
	nd_GsEglColor(nd_COLORYELLOW, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);

	j = (++k);
	k = j + (nd_GsPacketSortTime >> div);		// �p�P�b�g�\�[�g���� 
	nd_GsEglColor(nd_COLORWHITE, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);

	j = (++i);
	i += rendtime >> div;
	nd_GsEglColor(nd_COLORPURPLE, 0, 256);
	nd_GsEglBoxfill(j,10, i,13);				// �����_�����O�S�̂̏������� 

	k = j + (nd_GsFillTime >> div);
	nd_GsEglColor(nd_COLORBLUE, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);				// ��ʃt�B�� 

	j = (++k);
	k = j + ((nd_GsGpuRenderTime - nd_GsGpuWaitTime) >> div);
	nd_GsEglColor(nd_COLORYELLOW, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);				// �����_�����O 

	j = (++k);
	k = j + (nd_GsGpuWaitTime >> div);
	nd_GsEglColor(nd_COLORRED, 0, 256);
	nd_GsEglBoxfill(j,12, k,13);				// �`��G���W���I���҂� 
}

/* �����ʒu�ݒ� */
void set_light_vector(nd_rad rz)
{
	int s,c;

	nd_GsGetCosSin(rz,&c,&s);

	WorkFrame.l.vec_x = (-c * 3617) >> 12;
	WorkFrame.l.vec_y = -1923;
	WorkFrame.l.vec_z = (-s * 3617) >> 12;
}


int main(void)
{
//	nd_info_workframe *pWF;
	nd_u32 frctmp;
	int i,page=0,light=0;
	int md_roll=0,speed=3000,tire_roll=0,tire_tex_base;

	struct def_vrammap {
		nd_s32 baseline;
		nd_u32 memaddr;
	} vb[2];

	vb[0].baseline = 0;
	vb[0].memaddr  = GPU_S3_BASE + 0x81000000UL + (vb[0].baseline * na_VRAM_linesize);
	vb[1].baseline = 512;
	vb[1].memaddr  = GPU_S3_BASE + 0x81000000UL + (vb[1].baseline * na_VRAM_linesize);


	// �J�X�^�����߃e�X�g 
  #ifdef __PIXELSIMD
	printf("pyuvdec  :  0x%08X\n", ALT_CI_PIXELSIMD(0, 0x0000ffff, 0x00008080) );
	printf("ppack    :  0x%08X\n", ALT_CI_PIXELSIMD(1, 0x008090a0, 0x00102030) );
	printf("punpackl :  0x%08X\n", ALT_CI_PIXELSIMD(2, 0x03e87fff, 0         ) );
	printf("punpackh :  0x%08X\n", ALT_CI_PIXELSIMD(3, 0x03e87fff, 0         ) );
	printf("pblend   :  0x%08X\n", ALT_CI_PIXELSIMD(4, 0xff8090a0, 0x00102030) );
	printf("paddsb   :  0x%08X\n", ALT_CI_PIXELSIMD(6, 0x7f808182, 0x7e7f8081) );
	printf("psubsb   :  0x%08X\n", ALT_CI_PIXELSIMD(7, 0x7f808182, 0x80808080) );
  #endif


	// �t�@�C���V�X�e�������� 
	mmcfs_setup();

	// �O���t�B�b�N������ 
//	nd_GsVgaInit();
	ILI9325_init();
	nd_GsEglPage(vb[0].memaddr, vb[0].memaddr, 0);

	// �|���S���T�[�r�X�������� 
	nd_GsPolygonInit();
	nd_GsTextureInit();

	// ���[�N�t���[���������� 
	nd_GsInitWork(&WorkFrame, (void *)j7work, sizeof(j7work));
	nd_GsInitOT(&WorkFrame, 2000,2,5, 2000);

//	WorkFrame.rendermode &= ~gpu_dithering_enable;
	WorkFrame.v.x = 0;
	WorkFrame.v.y = -1000;
	WorkFrame.v.z = -4200;
	WorkFrame.l.lc.amb_r = 1400;
	WorkFrame.l.lc.amb_g = 1400;
	WorkFrame.l.lc.amb_b = 1400;

	nd_GsSetView2(&WorkFrame, 0,-280,0, 0,-1000,0);

	printf("Work size %d\r\n",(nd_s32)sizeof(j7work));
	printf("Work top : 0x%08x\r\n",(nd_u32)WorkFrame.pWork_top);
	printf("OT first : 0x%08x\r\n",(nd_u32)WorkFrame.pOT_top);
	printf("OT final : 0x%08x\r\n",(nd_u32)(WorkFrame.pOT_top + WorkFrame.ot_num*2));
	printf("Pkt1 top : 0x%08x\r\n",(nd_u32)WorkFrame.pPacket1_top);
	printf("Pkt2 top : 0x%08x\r\n",(nd_u32)WorkFrame.pPacket2_top);
	printf("Cstk top : 0x%08x\r\n",(nd_u32)WorkFrame.pCalctmp_top);
	printf("Work end : 0x%08x\r\n",(nd_u32)WorkFrame.pWork_end);


	// ���f���C���f�N�X�������� 
	model_init();

	// �p�b�h�R���g���[���������� 
//	nd_PadconInit();
//	nd_PadconSet(0,nd_padtype_psctp);	// PORT-A��PSCTP���[�h�ɂ��� 


	// ���[�v
	while(1) {
		nd_frc_init();

/*		// �ԑ̂̃p�����[�^���X�V 
		if ( nd_PadconCheck(0, nd_PSCTP_btn_start, nd_PADCHECK_TRIG_ON) ) {		// ���[�e�[�V������ON/OFF
			md_roll = ~md_roll;
		}
		if ( !md_roll ) {
			id_carbody.ry += 220;
		} else {
			if ( nd_PadconCheck(0, nd_PSCTP_btn_left, nd_PADCHECK_PUSH) ) {
				id_carbody.ry += 128;
			} else if ( nd_PadconCheck(0, nd_PSCTP_btn_right, nd_PADCHECK_PUSH) ) {
				id_carbody.ry -= 128;
			}
			if ( nd_PadconCheck(0, nd_PSCTP_btn_up, nd_PADCHECK_PUSH) ) {
				id_carbody.rx += 128;
			} else if ( nd_PadconCheck(0, nd_PSCTP_btn_down, nd_PADCHECK_PUSH) ) {
				id_carbody.rx -= 128;
			}
		}
		if ( nd_PadconCheck(0, nd_PSCTP_btn_L1, nd_PADCHECK_PUSH) ) {
			WorkFrame.v.z -= 100;
			nd_GsSetView2(&WorkFrame, 0,-280,0, 0,-1000,0);
		} else if ( nd_PadconCheck(0, nd_PSCTP_btn_R1, nd_PADCHECK_PUSH) ) {
			WorkFrame.v.z += 100;
			nd_GsSetView2(&WorkFrame, 0,-280,0, 0,-1000,0);
		}
*/
		id_carbody.ry += 220;

		// �^�C���̃p�����[�^�X�V�i�X�e�A�����O�A���x�j
//		id_cartire[0].ry = (nd_PadconOption(0, nd_PSCTP_rxdread | nd_PSCTP_analog_LH) - 128)<< 6;
//		id_cartire[1].ry = -id_cartire[0].ry;

		tire_roll = (tire_roll + speed) & 0xffff;
		id_cartire[0].rx = tire_roll;
		id_cartire[1].rx = -id_cartire[0].rx;
		id_cartire[2].rx =  id_cartire[0].rx;
		id_cartire[3].rx = -id_cartire[0].rx;

/*		if( nd_PadconCheck(0, nd_PSCTP_btn_sikaku, nd_PADCHECK_PUSH) ) {			// ���� 
			speed += (8000 - speed) >> 5;
		} else if ( nd_PadconCheck(0, nd_PSCTP_btn_batu, nd_PADCHECK_PUSH) ) {	// ���� 
			speed -= 100;
			if (speed < 0) speed = 0;
		}
*/
		if (speed > 5000) {
			tire_tex_base = 144 << 12;
		} else if (speed > 1500) {
			tire_tex_base = 72 << 12;
		} else {
			tire_tex_base = 0;
		}
		for(i=0 ; i<4 ; i++) id_cartire[i].tex_yadj = tire_tex_base;


		// ���C�e�B���O
		light = (light + 50) & 0xffff;
		set_light_vector(light);


/*		// �`�惂�[�h�ݒ� 
		if ( nd_PsctpCheckButton(nd_PSCTP_btn_batu, nd_PSCTP_BTN_TRIG_ON) )
			md_blf = ~md_blf;

		if (md_blf == 0) {
			WorkFrame.rendermode |= gpu_biliner_enable;
		} else {
			WorkFrame.rendermode &= ~gpu_biliner_enable;
		}
		if ( nd_PSCTP_push(nd_PSCTP_btn_L1) ) {
			WorkFrame.rendermode |= gpu_dithering_enable;
		} else if ( nd_PSCTP_push(nd_PSCTP_btn_L2) ) {
			WorkFrame.rendermode &= ~gpu_dithering_enable;
		} else if ( nd_PSCTP_push(nd_PSCTP_btn_R1) ) {
			WorkFrame.rendermode &= ~(3<<9);
			WorkFrame.rendermode |= gpu_dither_random;
		} else if ( nd_PSCTP_push(nd_PSCTP_btn_R2) ) {
			WorkFrame.rendermode &= ~(3<<9);
			WorkFrame.rendermode |= gpu_dither_pattern;
		}
*/

		// PSCTP�ʐM 
//		nd_PadconStart();

		// ���f�����n�s�֓o�^ 
		nd_GsVertexGeoTime = 0;
		nd_GsVertexPersTime = 0;
		nd_GsNormalCalcTime = 0;
		nd_GsPacketSortTime = 0;
		frctmp = nd_frc_getcount();

		nd_GsSetModel(&WorkFrame, &id_carbody, nd_use_rotation);
		for(i=0 ; i<4 ; i++) {
			nd_GsSetModel(&WorkFrame, &id_cartire[i], nd_use_rotation);
		}
		nd_GsSetModel(&WorkFrame, &id_carshadow, nd_use_rotation);

		geotime = nd_frc_getdiff(frctmp);

		// �n�s��`�� 
		nd_GsFillTime = 0;
		nd_GsGpuRenderTime = 0;
		nd_GsGpuWaitTime = 0;
		frctmp = nd_frc_getcount();

		nd_GsDrawOT(&WorkFrame, BG_COLOR);

		rendtime = nd_frc_getdiff(frctmp);

		// �^�C�}�[�l�\�� 
		draw_workmeter();

		// �`��y�[�W�ƕ\���y�[�W�����ւ� 
//		while( g_framebusy ) {}							// �K��̃t���[�����ԑ҂� 

		nd_GsEglPage(vb[page].memaddr, vb[1-page].memaddr, 0);
		WorkFrame.vram_base = vb[1-page].baseline;

		page = 1 - page;
	}


	printf("\n\ndone.\n");

	return(0);
}
