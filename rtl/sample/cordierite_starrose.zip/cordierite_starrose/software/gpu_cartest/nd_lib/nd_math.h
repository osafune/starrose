/**************************************************************************
	PROCYON �R���\�[�����C�u�����und_lib�v (MORGEN Edition)

		�Z�p���Z�֐��w�b�_

 **************************************************************************/
#ifndef __nd_math_lib_
#define __nd_math_lib_

#include "nd_config.h"


/***** �萔�E�}�N����` ***************************************************/

#ifndef nd_GsCodeImul			// ��Z�}�N�� 
#define nd_GsCodeImul(_x,_y)		((_x) * (_y))
#endif
#ifndef nd_GsCodeIdiv			// ���Z�}�N�� 
#define nd_GsCodeIdiv(_x,_y)		((_x) / (_y))
#endif

#ifdef _USE_MTRANDOM_
#define nd_srand(_s)		nd_GsInitRandMT((nd_u32)(_s))
#define nd_rand()			((nd_s32)((nd_GsGetRandMT() & 0x7fffffff)>> 16))
#else
#define nd_srand(_s)		nd_GsInitRand((nd_u32)(_s))
#define nd_rand()			((nd_s32)((nd_GsGetRand() & 0x7fffffff)>> 16))
#endif


/***** �\���́E�ϐ��^��` *************************************************/

typedef nd_s32	nd_f12;				// 12bit�Œ菬���^
typedef nd_s32	nd_rad;				// 2��=65536�Ƃ��郉�W�A���^


/***** �v���g�^�C�v�錾 ***************************************************/

extern nd_s32 nd_GsGetSqrt(nd_s32);
extern nd_f12 nd_GsGetSqrtFix(nd_s32);
extern nd_f12 nd_GsGetHypot3D(nd_f12, nd_f12, nd_f12);
extern nd_f12 nd_GsGetScalar3D(nd_f12, nd_f12, nd_f12);
extern void nd_GsGetCosSin(nd_rad, nd_f12 *, nd_f12 *);
extern nd_f12 nd_GsGetCos2(nd_f12);
extern nd_f12 nd_GsGetSin2(nd_f12);
extern nd_f12 nd_GsGetSinx(nd_f12);
extern nd_rad nd_GsGetAtan(nd_s32, nd_s32);
extern void nd_GsInitRandMT(nd_u32 seed);
extern nd_u32 nd_GsGetRandMT(void);
extern void nd_GsInitRand(nd_u32 seed);
extern nd_u32 nd_GsGetRand(void);



#endif
/**************************************************************************/
