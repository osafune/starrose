#ifndef __nd_drawpolygon_h_
#define __nd_drawpolygon_h_

//#ifndef _use_drawtriangle_
#if 0

#include "gs_polygon.h"
extern nd_u32 nd_GsGpuWaitTime;

#else

#include "gs_triangle.h"
#define nd_GsPolygonExit()
#define nd_GsPolygonWait()

#endif

#endif
