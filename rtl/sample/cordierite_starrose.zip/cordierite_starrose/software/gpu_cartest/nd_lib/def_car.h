#ifndef __def_car_h_
#define __def_car_h_

#include "nd_n3d.h"

#define carbody_tex_base		(0)
#define cartire_tex_base		(256)

#define cartire_zoffset			(250)		// �^�C���̂y�I�t�Z�b�g�l 

#define cartire_fl_rz			(0)			// ���t�����g�^�C�� 
#define cartire_fl_offx			(-440)
#define cartire_fl_offy			(-160)
#define cartire_fl_offz			(-700)
#define cartire_fr_rz			(32768)		// �E�t�����g�^�C�� 
#define cartire_fr_offx			(440)
#define cartire_fr_offy			(-160)
#define cartire_fr_offz			(-700)
#define cartire_rl_rz			(0)			// �����A�^�C�� 
#define cartire_rl_offx			(-460)
#define cartire_rl_offy			(-160)
#define cartire_rl_offz			(710)
#define cartire_rr_rz			(32768)		// �E���A�^�C�� 
#define cartire_rr_offx			(460)
#define cartire_rr_offy			(-160)
#define cartire_rr_offz			(710)

#define carshadow_zoffset		(500)		// �e�̂y�I�t�Z�b�g�l 


typedef struct {				/* ���w�� */
	nd_u16	mode;
	nd_u16	tmode;
	nd_u16	p0;
	nd_u8	u0,v0;
	nd_u16	p1;
	nd_u8	u1,v1;
	nd_u16	p2;
	nd_u8	u2,v2;
	nd_u16	nv0,nv1,nv2;
	nd_s16	reserved;
} __attribute__ ((packed)) nd_N3D_primitive_P3TG_old;

typedef struct {				/* ���w�� */
	nd_u16	mode;
	nd_u16	tmode;
	nd_u16	p0;
	nd_u8	u0,v0;
	nd_u16	p1;
	nd_u8	u1,v1;
	nd_u16	p2;
	nd_u8	u2,v2;
	nd_u16	p3;
	nd_u8	u3,v3;
	nd_u16	nv0,nv1,nv2,nv3;
} __attribute__ ((packed)) nd_N3D_primitive_P4TG_old;


typedef struct {
	nd_N3D_header	h;
	nd_N3D_objtable	t;
	nd_N3D_textable tb;
	nd_N3D_primitive_P3G	p0[24];
	nd_N3D_primitive_P3		p0_0[21];
	nd_N3D_primitive_P3TG_old	p1[30];
	nd_N3D_primitive_P4G	p2[27];
	nd_N3D_primitive_P4		p2_0[2];
	nd_N3D_primitive_P4TG_old	p3[48];
	nd_N3D_vertex	v[128];
	nd_N3D_nvector	nv[128];
} n3d_DEF_carbody;

typedef struct {
	nd_N3D_header h;
	nd_N3D_objtable t;
	nd_N3D_textable tb;
	nd_N3D_primitive_P4		p0[18];
	nd_N3D_primitive_P4TG_old	p1[11];
	nd_N3D_vertex v[31];
	nd_N3D_nvector nv[31];
} n3d_DEF_cartire;

typedef struct {
	nd_N3D_header h;
	nd_N3D_objtable t;
	nd_N3D_primitive_P4		p0[6];
	nd_N3D_vertex v[14];
} n3d_DEF_carshadow;


typedef const struct {
	nd_TEX_header th;
	nd_u8 texdata[35092];
} n3d_DEF_carbody_tex;

typedef const struct {
	nd_TEX_header th;
	nd_u8 texdata[26070];
} n3d_DEF_cartire_tex;


extern n3d_DEF_carbody carbody;
extern n3d_DEF_cartire cartire;
extern n3d_DEF_carshadow carshadow;
extern n3d_DEF_carbody_tex carbody_tex;
extern n3d_DEF_cartire_tex cartire_tex;

#endif
