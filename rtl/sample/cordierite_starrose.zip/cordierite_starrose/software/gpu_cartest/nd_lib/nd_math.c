/**************************************************************************
	PROCYON �R���\�[�����C�u�����und_Lib�v (MORGEN Edition)

		�Z�p���Z�֐�

 **************************************************************************/

#include "nd_math.h"


/**************************************************************************
	���������擾
 **************************************************************************/
/*
  �`���P 
	nd_s32 nd_GsGetSqrt(nd_s32 x)

  �@�\
	32�r�b�g�����t�������̕������𐮐��l�ŕԂ��B
	�����̏ꍇ�͂O��Ԃ��B


  �`���Q 
	nd_f12 nd_GsGetSqrtFix(nd_f12 x)

  �@�\
	32�r�b�g�����t���Œ菭��(12bitFIX)�̕�������Ԃ��B
	���͒l�������̏ꍇ�͂O��Ԃ��B
	�ő�덷�͓��͒l��64.0�ȉ��̏ꍇ��0.01%�A64.0�ȏ��0.78%
*/

/* �����񕪊�@�Ōv�Z(2^30�ȉ��̏ꍇ) */
static nd_s32 nd_GsGetSqrt_subBiTree(nd_s32 x)
{
	nd_s32 i,j,ans=16384;

	/* 2^15����_�ɓ񕪊򌟍������� */
	for(i=8192 ; i>=1 ; i>>=1) {
		j = nd_GsCodeImul(ans , ans);

		if(x == j) {
			i = -1;
			break;
		} else if(x > j) {
			ans += i;
		} else {
			ans -= i;
		}
	}

	/* �����l�ۂ� */
	if(i != -1) {
		if(x > nd_GsCodeImul(ans , ans)) ans++;
		if(x < nd_GsCodeImul(ans , ans)) ans--;
		j = nd_GsCodeImul(ans , ans) + ans + 1;
		if(x >= j) ans++;
	}

    return(ans);
}

/* �j���[�g���@�Ōv�Z(2^30�ȏ�̏ꍇ) */
static nd_s32 nd_GsGetSqrt_subNewton(nd_s32 x)
{
	nd_s32 s,t;

	/* �������ɂȂ�ׂ��߂��傫�����̐�����T�� */
	s = 1;
	t = x;
	while(s < t) {
		s <<= 1;
		t >>= 1;
	}

	/* �j���[�g���@�ŋߎ��l�����߂� */
	do {
		t = s;
		s = (s + nd_GsCodeIdiv(x , s)) >> 1;
	} while(s < t);

	return(t);
}


/***** �������������v�Z **********/
nd_s32 nd_GsGetSqrt(
	nd_s32 x)
{
	nd_s32 ans;

	if(x <= 0) return(0);

	if(x < (32768 * 32768)) {
		ans = nd_GsGetSqrt_subBiTree(x);
	} else {
		ans = nd_GsGetSqrt_subNewton(x);
	}

	return(ans);
}


/***** �Œ菭���^�̐������������v�Z **********/
nd_f12 nd_GsGetSqrtFix(
	nd_f12 x)
{
	nd_f12 ans;

	if(x <= 0) return(0);

	/* 64.0�ȉ��̏ꍇ�͗\��12bit�����グ */
	if(x < (64 * 4096)) {
		ans = (nd_f12)nd_GsGetSqrt_subBiTree(x<<12);
	} else {
		ans = (nd_f12)nd_GsGetSqrt(x) << 6;
	}

	return(ans);
}



/**************************************************************************
	�R�����x�N�g���̃X�J�����擾
 **************************************************************************/
/*
  �`���P 
	nd_f12 nd_GsGetHypot3D(nd_f12 vx,nd_f12 vy,nd_f12 vz)

  �@�\ 
	�R�����x�N�g��(vx,vy,vz)�̃X�J���ʂ�12bit�Œ菭���l�ŕԂ��i����������6bit�͖����j�B
	�ߎ��v�Z���s�����߁A�ő�V���̌덷������̂Œ��ӂ��邱�ƁB


  �`���Q 
	nd_f12 nd_GsGetScalar3D(nd_f12 vx,nd_f12 vy,nd_f12 vz)

  �@�\ 
	�R�����x�N�g��(vx,vy,vz)�̃X�J���ʂ�12bit�Œ菭���l�ŕԂ��B
	�������A|vx|+|vy|+|vz| �� 64.0 �̏����ł� nd_GsGetHypot3D�֐��ɒl�������p���B

*/

/***** �n�C�p�{���b�N���Z **********/
nd_f12 nd_GsGetHypot3D(
	nd_f12 vx, nd_f12 vy, nd_f12 vz)		// 12bit�Œ菭�� 
{
	nd_f12 tmp;

	if(vx < 0) vx = -vx;
	if(vy < 0) vy = -vy;
	if(vz < 0) vz = -vz;

	if(vx < vy) {
		tmp = vx;	vx  = vy;	vy  = tmp;
	}
	if(vy < vz) {
		tmp = vy;	vy  = vz;	vz  = tmp;
	}
	if(vx < vy) {
		tmp = vx;	vx  = vy;	vy  = tmp;
	}

	vx <<= 12;
	vy <<= 12;
	vz <<= 12;

//	hypot = 0.9604 * i + 0.3978 * j + 0.296875 * k  (������ i �� j �� k)
	tmp  = (vx >> 1) + (vx >> 2) + (vx >> 3) + (vx >> 4);	// 0.9375 = 1/2 + 1/4 + 1/8 + 1/16
	tmp += (vy >> 2) + (vy >> 3) + (vy >> 6);				// 0.390625 = 1/4 + 1/8 + 1/64
	tmp += (vz >> 2) + (vz >> 5) + (vz >> 6);				// 0.296875 = 1/4 + 1/32 + 1/64

	return(tmp);
}


/***** �X�J���[�����߂� **********/
nd_f12 nd_GsGetScalar3D(
	nd_f12 vx, nd_f12 vy, nd_f12 vz)		// 12bit�Œ菭�� 
{
	nd_s32	tmp;
	nd_f12 ans;

	if(vx < 0) vx = -vx;
	if(vy < 0) vy = -vy;
	if(vz < 0) vz = -vz;

	if((vx + vy + vz) > 32767) {
		ans = nd_GsGetHypot3D(vx, vy, vz);
	} else {
		tmp  = nd_GsCodeImul((nd_s32)vx, (nd_s32)vx);
		tmp += nd_GsCodeImul((nd_s32)vy, (nd_s32)vy);
		tmp += nd_GsCodeImul((nd_s32)vz, (nd_s32)vz);
		ans  = (nd_f12)nd_GsGetSqrt_subBiTree(tmp);
	}

	return(ans);
}



/**************************************************************************
	�O�p�֐��l���擾
 **************************************************************************/
/*
  �`�� 
	void nd_GsGetCosSin(nd_rad rad, nd_f12 *c, nd_f12 *s)

  �@�\
	rad�l��cos�l��sin�l���擾�Brad�͂P����65536(2��=65536)�Ƃ��郉�W�A���p�B
	�͈͐�����int�ɏ�����Bcos,sin�Ƃ���12bit�Œ菭���l��Ԃ��B
*/
void nd_GsGetCosSin(
		nd_rad rad,		// �P����65536(2��=65536)�Ƃ��郉�W�A���p 
		nd_f12 *c,			// cos�l���i�[����ϐ��|�C���^(12bit�Œ菭��) 
		nd_f12 *s)			// sin�l���i�[����ϐ��|�C���^(12bit�Œ菭��) 
{
	int i;
	const nd_u16 matcos_table[] = {
		0x1000,0x0FFF,0x0FFF,0x0FFF,0x0FFE,0x0FFE,0x0FFD,0x0FFC,
		0x0FFB,0x0FF9,0x0FF8,0x0FF6,0x0FF4,0x0FF2,0x0FF0,0x0FEE,
		0x0FEC,0x0FE9,0x0FE7,0x0FE4,0x0FE1,0x0FDE,0x0FDA,0x0FD7,
		0x0FD3,0x0FCF,0x0FCB,0x0FC7,0x0FC3,0x0FBF,0x0FBA,0x0FB6,
		0x0FB1,0x0FAC,0x0FA7,0x0FA1,0x0F9C,0x0F96,0x0F91,0x0F8B,
		0x0F85,0x0F7F,0x0F78,0x0F72,0x0F6B,0x0F64,0x0F5D,0x0F56,
		0x0F4F,0x0F48,0x0F40,0x0F39,0x0F31,0x0F29,0x0F21,0x0F18,
		0x0F10,0x0F08,0x0EFF,0x0EF6,0x0EED,0x0EE4,0x0EDB,0x0ED1,
		0x0EC8,0x0EBE,0x0EB4,0x0EAA,0x0EA0,0x0E96,0x0E8B,0x0E81,
		0x0E76,0x0E6B,0x0E60,0x0E55,0x0E4A,0x0E3F,0x0E33,0x0E28,
		0x0E1C,0x0E10,0x0E04,0x0DF8,0x0DEB,0x0DDF,0x0DD2,0x0DC6,
		0x0DB9,0x0DAC,0x0D9F,0x0D91,0x0D84,0x0D77,0x0D69,0x0D5B,
		0x0D4D,0x0D3F,0x0D31,0x0D23,0x0D14,0x0D06,0x0CF7,0x0CE8,
		0x0CD9,0x0CCA,0x0CBB,0x0CAC,0x0C9D,0x0C8D,0x0C7D,0x0C6E,
		0x0C5E,0x0C4E,0x0C3E,0x0C2D,0x0C1D,0x0C0D,0x0BFC,0x0BEB,
		0x0BDA,0x0BCA,0x0BB8,0x0BA7,0x0B96,0x0B85,0x0B73,0x0B62,
		0x0B50,0x0B3E,0x0B2C,0x0B1A,0x0B08,0x0AF6,0x0AE3,0x0AD1,
		0x0ABE,0x0AAC,0x0A99,0x0A86,0x0A73,0x0A60,0x0A4D,0x0A39,
		0x0A26,0x0A12,0x09FF,0x09EB,0x09D7,0x09C4,0x09B0,0x099C,
		0x0987,0x0973,0x095F,0x094B,0x0936,0x0921,0x090D,0x08F8,
		0x08E3,0x08CE,0x08B9,0x08A4,0x088F,0x087A,0x0864,0x084F,
		0x0839,0x0824,0x080E,0x07F8,0x07E2,0x07CD,0x07B7,0x07A0,
		0x078A,0x0774,0x075E,0x0748,0x0731,0x071B,0x0704,0x06ED,
		0x06D7,0x06C0,0x06A9,0x0692,0x067B,0x0664,0x064D,0x0636,
		0x061F,0x0608,0x05F0,0x05D9,0x05C2,0x05AA,0x0593,0x057B,
		0x0563,0x054C,0x0534,0x051C,0x0504,0x04EC,0x04D5,0x04BD,
		0x04A5,0x048C,0x0474,0x045C,0x0444,0x042C,0x0413,0x03FB,
		0x03E3,0x03CA,0x03B2,0x0399,0x0381,0x0368,0x0350,0x0337,
		0x031F,0x0306,0x02ED,0x02D5,0x02BC,0x02A3,0x028A,0x0271,
		0x0259,0x0240,0x0227,0x020E,0x01F5,0x01DC,0x01C3,0x01AA,
		0x0191,0x0178,0x015F,0x0146,0x012D,0x0114,0x00FB,0x00E2,
		0x00C8,0x00AF,0x0096,0x007D,0x0064,0x004B,0x0032,0x0019,
		0x0000
	};

	rad = rad >> 6;
	i   =(rad & 0xff);

	switch(rad & 0x300) {
	case(0x000):			/* ��P�ی� */
		*c =(nd_f12)(matcos_table[i]);
		*s =(nd_f12)(matcos_table[(256-i)]);
		break;

	case(0x100):			/* ��Q�ی� */
		*c =(nd_f12)(-matcos_table[(256-i)]);
		*s =(nd_f12)( matcos_table[i]);
		break;

	case(0x200):			/* ��R�ی� */
		*c =(nd_f12)(-matcos_table[i]);
		*s =(nd_f12)(-matcos_table[(256-i)]);
		break;

	case(0x300):			/* ��S�ی� */
		*c =(nd_f12)( matcos_table[(256-i)]);
		*s =(nd_f12)(-matcos_table[i]);
		break;
	};
//	if((rad & 0x300) == 0x000) {			/* ��P�ی� */
//		*c =(nd_f12)(matcos_table[i]);
//		*s =(nd_f12)(matcos_table[(256-i)]);
//	} else if((rad & 0x300) == 0x100) {		/* ��Q�ی� */
//		*c =(nd_f12)(-matcos_table[(256-i)]);
//		*s =(nd_f12)( matcos_table[i]);
//	} else if((rad & 0x300) == 0x200) {		/* ��R�ی� */
//		*c =(nd_f12)(-matcos_table[i]);
//		*s =(nd_f12)(-matcos_table[(256-i)]);
//	} else { 								/* ��S�ی� */
//		*c =(nd_f12)( matcos_table[(256-i)]);
//		*s =(nd_f12)(-matcos_table[i]);
//	}
}



/**************************************************************************
	�O�p�������낢��
 **************************************************************************/

/***** ���p���� **********/
// cos(x/2) = �}sqrt( (1.0 + cos(x))/2 )  cos(x)�̕����Ɠ��� 
nd_f12 nd_GsGetCos2(		// cos�Ƃ���cos(��/2)�����߂� 
		nd_f12 cosx)		// cos�� (12bit�Œ菭��) 
{
	nd_f12 cos2;

	cos2 = nd_GsGetSqrt_subBiTree( (4096 + (nd_s32)cosx)<< 11);
	if(cosx < 0) cos2 = -cos2;

	return(cos2);
}

// sin(x/2) = �}sqrt( (1.0 - cos(x))/2 ) 
nd_f12 nd_GsGetSin2(		// cos�Ƃ���sin(��/2)�����߂� 
		nd_f12 cosx)		// cos�� (12bit�Œ菭��) 
{
	nd_f12 sin2;

	sin2 = nd_GsGetSqrt_subBiTree( (4096 - (nd_s32)cosx)<< 11);

	return(sin2);
}


/***** ������� **********/
// sin(x) = sqrt(1.0 - cos(x)^2)
nd_f12 nd_GsGetSinx(		// cos�Ƃ���sin�Ƃ����߂� 
		nd_f12 cosx)		// cos�� (12bit�Œ菭��) 
{
	nd_f12 sinx;

	sinx = nd_GsGetSqrt_subBiTree( 4096*4096 - nd_GsCodeImul(cosx, cosx) );

	return(sinx);
}



/**************************************************************************
	arcTAN�l���擾
 **************************************************************************/
/*
  �`�� 
	nd_rad nd_GsGetAtan(nd_s32 x, nd_s32 y)

  �@�\
	�x�N�g��(x,y)�̊p�x��rad�l(�P����65536�Ƃ��郉�W�A���p)�ŕԂ��B
	���͔͈͐�����(-2^22)�`(2^22-1)�B
*/

/* p0��p1�̊Ԃ�16�_�Œ�����Ԃ��� */
static nd_rad nd_GsGetAtan_subLiner(
		nd_rad p0,
		nd_rad p1,
		nd_s32 a)
{
	switch(a & 15) {
	case(0):  return( p0 );
	case(1):  return( ((p0<<4)-p0 + p1)>>4 );
	case(2):  return( ((p0<<3)-p0 + p1)>>3 );
	case(3):  return( ((p0<<4)-(p0<<1)-p0 + (p1<<1)+p1)>>4 );
	case(4):  return( ((p0<<1)+p0 + p1)>>2 );
	case(5):  return( ((p0<<3)+(p0<<1)+p0 + (p1<<2)+p1)>>4 );
	case(6):  return( ((p0<<2)+p0 + (p1<<1)+p1)>>3 );
	case(7):  return( ((p0<<3)+p0 + (p1<<3)-p1)>>4 );
	case(8):  return( (p0 + p1)>>1 );
	case(9):  return( ((p1<<3)+p1 + (p0<<3)-p0)>>4 );
	case(10): return( ((p1<<2)+p1 + (p0<<1)+p0)>>3 );
	case(11): return( ((p1<<3)+(p1<<1)+p1 + (p0<<2)+p0)>>4 );
	case(12): return( ((p1<<1)+p1 + p0)>>2 );
	case(13): return( ((p1<<4)-(p1<<1)-p1 + (p0<<1)+p0)>>4 );
	case(14): return( ((p1<<3)-p1 + p0)>>3 );
	case(15): return( ((p1<<4)-p1 + p0)>>4 );
	};

	return(0);
}

/* 0�`��/4�܂ł�arcTAN�e�[�u�� */
static nd_rad nd_GsGetAtan_subTableLookup(
		nd_s32 ax,
		nd_s32 ay)
{
	nd_s32 i,j,ans;
	const nd_u16 atan_table[] = {
		0x0000,0x0014,0x0028,0x003d,0x0051,0x0065,0x007a,0x008e,
		0x00a2,0x00b7,0x00cb,0x00e0,0x00f4,0x0108,0x011d,0x0131,
		0x0145,0x015a,0x016e,0x0182,0x0197,0x01ab,0x01bf,0x01d4,
		0x01e8,0x01fc,0x0211,0x0225,0x0239,0x024e,0x0262,0x0276,
		0x028b,0x029f,0x02b3,0x02c7,0x02dc,0x02f0,0x0304,0x0318,
		0x032d,0x0341,0x0355,0x0369,0x037e,0x0392,0x03a6,0x03ba,
		0x03ce,0x03e3,0x03f7,0x040b,0x041f,0x0433,0x0448,0x045c,
		0x0470,0x0484,0x0498,0x04ac,0x04c0,0x04d4,0x04e8,0x04fd,
		0x0511,0x0525,0x0539,0x054d,0x0561,0x0575,0x0589,0x059d,
		0x05b1,0x05c5,0x05d9,0x05ed,0x0601,0x0614,0x0628,0x063c,
		0x0650,0x0664,0x0678,0x068c,0x06a0,0x06b3,0x06c7,0x06db,
		0x06ef,0x0703,0x0716,0x072a,0x073e,0x0752,0x0765,0x0779,
		0x078d,0x07a0,0x07b4,0x07c8,0x07db,0x07ef,0x0803,0x0816,
		0x082a,0x083d,0x0851,0x0864,0x0878,0x088b,0x089f,0x08b2,
		0x08c6,0x08d9,0x08ed,0x0900,0x0913,0x0927,0x093a,0x094d,
		0x0961,0x0974,0x0987,0x099b,0x09ae,0x09c1,0x09d4,0x09e8,
		0x09fb,0x0a0e,0x0a21,0x0a34,0x0a47,0x0a5a,0x0a6d,0x0a80,
		0x0a94,0x0aa7,0x0aba,0x0acd,0x0ae0,0x0af2,0x0b05,0x0b18,
		0x0b2b,0x0b3e,0x0b51,0x0b64,0x0b77,0x0b89,0x0b9c,0x0baf,
		0x0bc2,0x0bd4,0x0be7,0x0bfa,0x0c0c,0x0c1f,0x0c32,0x0c44,
		0x0c57,0x0c69,0x0c7c,0x0c8e,0x0ca1,0x0cb3,0x0cc6,0x0cd8,
		0x0ceb,0x0cfd,0x0d0f,0x0d22,0x0d34,0x0d46,0x0d58,0x0d6b,
		0x0d7d,0x0d8f,0x0da1,0x0db4,0x0dc6,0x0dd8,0x0dea,0x0dfc,
		0x0e0e,0x0e20,0x0e32,0x0e44,0x0e56,0x0e68,0x0e7a,0x0e8c,
		0x0e9e,0x0eaf,0x0ec1,0x0ed3,0x0ee5,0x0ef7,0x0f08,0x0f1a,
		0x0f2c,0x0f3d,0x0f4f,0x0f61,0x0f72,0x0f84,0x0f95,0x0fa7,
		0x0fb8,0x0fca,0x0fdb,0x0fed,0x0ffe,0x1010,0x1021,0x1032,
		0x1044,0x1055,0x1066,0x1077,0x1089,0x109a,0x10ab,0x10bc,
		0x10cd,0x10de,0x10ef,0x1100,0x1111,0x1122,0x1133,0x1144,
		0x1155,0x1166,0x1177,0x1188,0x1199,0x11a9,0x11ba,0x11cb,
		0x11dc,0x11ec,0x11fd,0x120e,0x121e,0x122f,0x123f,0x1250,
		0x1260,0x1271,0x1281,0x1292,0x12a2,0x12b3,0x12c3,0x12d3,
		0x12e4,0x12f4,0x1304,0x1314,0x1325,0x1335,0x1345,0x1355,
		0x1365,0x1375,0x1385,0x1395,0x13a5,0x13b5,0x13c5,0x13d5,
		0x13e5,0x13f5,0x1405,0x1415,0x1424,0x1434,0x1444,0x1454,
		0x1463,0x1473,0x1483,0x1492,0x14a2,0x14b1,0x14c1,0x14d0,
		0x14e0,0x14ef,0x14ff,0x150e,0x151e,0x152d,0x153c,0x154c,
		0x155b,0x156a,0x1579,0x1589,0x1598,0x15a7,0x15b6,0x15c5,
		0x15d4,0x15e3,0x15f2,0x1601,0x1610,0x161f,0x162e,0x163d,
		0x164c,0x165b,0x166a,0x1678,0x1687,0x1696,0x16a5,0x16b3,
		0x16c2,0x16d1,0x16df,0x16ee,0x16fc,0x170b,0x1719,0x1728,
		0x1736,0x1745,0x1753,0x1761,0x1770,0x177e,0x178c,0x179b,
		0x17a9,0x17b7,0x17c5,0x17d4,0x17e2,0x17f0,0x17fe,0x180c,
		0x181a,0x1828,0x1836,0x1844,0x1852,0x1860,0x186e,0x187c,
		0x188a,0x1897,0x18a5,0x18b3,0x18c1,0x18ce,0x18dc,0x18ea,
		0x18f7,0x1905,0x1913,0x1920,0x192e,0x193b,0x1949,0x1956,
		0x1964,0x1971,0x197f,0x198c,0x1999,0x19a7,0x19b4,0x19c1,
		0x19ce,0x19dc,0x19e9,0x19f6,0x1a03,0x1a10,0x1a1d,0x1a2a,
		0x1a37,0x1a44,0x1a51,0x1a5e,0x1a6b,0x1a78,0x1a85,0x1a92,
		0x1a9f,0x1aac,0x1ab9,0x1ac5,0x1ad2,0x1adf,0x1aec,0x1af8,
		0x1b05,0x1b12,0x1b1e,0x1b2b,0x1b37,0x1b44,0x1b50,0x1b5d,
		0x1b69,0x1b76,0x1b82,0x1b8f,0x1b9b,0x1ba7,0x1bb4,0x1bc0,
		0x1bcc,0x1bd9,0x1be5,0x1bf1,0x1bfd,0x1c09,0x1c16,0x1c22,
		0x1c2e,0x1c3a,0x1c46,0x1c52,0x1c5e,0x1c6a,0x1c76,0x1c82,
		0x1c8e,0x1c9a,0x1ca5,0x1cb1,0x1cbd,0x1cc9,0x1cd5,0x1ce0,
		0x1cec,0x1cf8,0x1d04,0x1d0f,0x1d1b,0x1d26,0x1d32,0x1d3e,
		0x1d49,0x1d55,0x1d60,0x1d6c,0x1d77,0x1d83,0x1d8e,0x1d99,
		0x1da5,0x1db0,0x1dbb,0x1dc7,0x1dd2,0x1ddd,0x1de9,0x1df4,
		0x1dff,0x1e0a,0x1e15,0x1e20,0x1e2c,0x1e37,0x1e42,0x1e4d,
		0x1e58,0x1e63,0x1e6e,0x1e79,0x1e84,0x1e8f,0x1e99,0x1ea4,
		0x1eaf,0x1eba,0x1ec5,0x1ed0,0x1eda,0x1ee5,0x1ef0,0x1efb,
		0x1f05,0x1f10,0x1f1b,0x1f25,0x1f30,0x1f3a,0x1f45,0x1f4f,
		0x1f5a,0x1f64,0x1f6f,0x1f79,0x1f84,0x1f8e,0x1f99,0x1fa3,
		0x1fad,0x1fb8,0x1fc2,0x1fcc,0x1fd7,0x1fe1,0x1feb,0x1ff5,
		0x2000
	};

	if(ax == 0) {
		ans = 0;
	} else if(ax == ay) {
		ans = 8192;
	} else {
		i  = nd_GsCodeIdiv(ay << 13, ax);
		j  = nd_GsCodeIdiv(ay << 9, ax) & 0x1ff;
		ans= nd_GsGetAtan_subLiner((nd_rad)atan_table[j], (nd_rad)atan_table[j+1], i);
	}

	return(ans);
}

/* atan�֐��{�� */
nd_rad nd_GsGetAtan(
		nd_s32 x,
		nd_s32 y)
{
	nd_s32 ax,ay;
	nd_rad ans;

	if(x < 0) ax = -x; else ax = x;
	if(y < 0) ay = -y; else ay = y;

	if(ax >= ay) {				// |x|��|y|�̏ꍇ 
		ans = nd_GsGetAtan_subTableLookup(ax, ay);

		if(x >= 0) {
			if(y >= 0) {		// x��0,y��0�̏ꍇ 
				// �Ȃɂ����Ȃ� 
			} else {			// x��0,y��0�̏ꍇ 
				ans = 65536 - ans;
			}
		} else {
			if(y >= 0) {		// x��0,y��0�̏ꍇ 
				ans = 32768 - ans;
			} else {			// x��0,y��0�̏ꍇ 
				ans += 32768;
			}
		}

	} else {					// |x|��|y|�̏ꍇ 
		ans = nd_GsGetAtan_subTableLookup(ay, ax);

		if(y >= 0) {
			if(x >= 0) {		// y��0,x��0�̏ꍇ 
				ans = 16384 - ans;
			} else {			// y��0,x��0�̏ꍇ 
				ans += 16384;
			}
		} else {
			if(x >= 0) {		// y��0,x��0�̏ꍇ 
				ans += 49152;
			} else {			// y��0,x��0�̏ꍇ 
				ans = 49152 - ans;
			}
		}
	}

	return(ans & 0xffff);
}



/**************************************************************************
	�����_���l���擾

	nd_Lib�̃����_���֐���Mersenne Twister���g�p���Ă��܂��B
		http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/mt.html
 **************************************************************************/
/*
  �`�� 
	void nd_GsInitRandMT(nd_u32 seed)
	nd_u32 nd_GsGetRandMT(void)

	void nd_GsInitRand(nd_u32 seed)
	nd_u32 nd_GsGetRand(void)

  �@�\
	��������32bit�����l�Ń����_���l��Ԃ��B
*/


/* �����Z���k�E�c�C�X�^�[�ɂ�郉���_���֐� */
#define nd_RAND_N			(624)
#define nd_RAND_M			(397)
#define nd_RAND_MATRIX_A	(0x9908b0dfUL)	/* constant vector a */
#define nd_RAND_UPPER_MASK	(0x80000000UL)	/* most significant w-r bits */
#define nd_RAND_LOWER_MASK	(0x7fffffffUL)	/* least significant r bits */

static nd_u32 nd_GsRand_mt[nd_RAND_N];		/* the array for the state vector  */
static nd_s32 nd_GsRand_mti = nd_RAND_N+1;	/* mti==N+1 means mt[N] is not initialized */

void nd_GsInitRandMT(
		nd_u32 seed)
{
	nd_GsRand_mt[0] = seed & 0xffffffffUL;

	for (nd_GsRand_mti=1 ; nd_GsRand_mti<nd_RAND_N ; nd_GsRand_mti++) {
		nd_GsRand_mt[nd_GsRand_mti] = (1812433253UL * (nd_GsRand_mt[nd_GsRand_mti-1] ^ (nd_GsRand_mt[nd_GsRand_mti-1] >> 30)) + nd_GsRand_mti);
		nd_GsRand_mt[nd_GsRand_mti] &= 0xffffffffUL;
	}
}

nd_u32 nd_GsGetRandMT(
		void)
{
	nd_s32 kk;
	nd_u32 y;
	static nd_u32 mag01[2]={0x0UL, nd_RAND_MATRIX_A};

	if (nd_GsRand_mti >= nd_RAND_N) { /* generate N words at one time */

		if (nd_GsRand_mti == nd_RAND_N+1) nd_GsInitRandMT(5489UL);

		for (kk=0 ; kk<nd_RAND_N-nd_RAND_M ; kk++) {
			y = (nd_GsRand_mt[kk] & nd_RAND_UPPER_MASK)|(nd_GsRand_mt[kk+1] & nd_RAND_LOWER_MASK);
			nd_GsRand_mt[kk] = nd_GsRand_mt[kk+nd_RAND_M] ^ (y>>1) ^ mag01[y & 0x1UL];
		}
		for (; kk<nd_RAND_N-1 ; kk++) {
			y = (nd_GsRand_mt[kk] & nd_RAND_UPPER_MASK)|(nd_GsRand_mt[kk+1] & nd_RAND_LOWER_MASK);
			nd_GsRand_mt[kk] = nd_GsRand_mt[kk+(nd_RAND_M-nd_RAND_N)] ^ (y>>1) ^ mag01[y & 0x1UL];
		}
		y = (nd_GsRand_mt[nd_RAND_N-1] & nd_RAND_UPPER_MASK)|(nd_GsRand_mt[0] & nd_RAND_LOWER_MASK);
		nd_GsRand_mt[nd_RAND_N-1] = nd_GsRand_mt[nd_RAND_M-1] ^ (y>>1) ^ mag01[y & 0x1UL];

		nd_GsRand_mti = 0;
	}

	y = nd_GsRand_mt[nd_GsRand_mti++];

    /* Tempering */
	y ^= (y >> 11);
	y ^= (y << 7) & 0x9d2c5680UL;
	y ^= (y << 15) & 0xefc60000UL;
	y ^= (y >> 18);

	return y;
}


/* ���`�����@�ɂ�鍂�������_���֐� */
static nd_u32 nd_GsGetRand_x[32] = {
	0x00000003,0x9A319039,0x32D9C024,0x9B663182,
	0x5DA1F342,0xDE3B81E0,0xDF0A6FB5,0xF103BC02,
	0x48F340FB,0x7449E56B,0xBEB1DBB0,0xAB5C5918,
	0x946554FD,0x8C2E680F,0xEB3D799F,0xB11EE0B7,
	0x2D436B86,0xDA672E2A,0x1588CA88,0xE369735D,
	0x904F35F7,0xD7158FD6,0x6FA6F051,0x616E6B96,
	0xAC94EFDC,0x36413F93,0xC622C298,0xF5A42AB8,
	0x8A88D77B,0xF5AD9D0E,0x8999220B,0x27FB47B9};

void nd_GsInitRand(
		nd_u32 seed)
{
    int i;

    nd_GsGetRand_x[0] = 3;
	nd_GsGetRand_x[1] = seed;
    for(i=2 ; i<=31 ; i++)
		nd_GsGetRand_x[i] = 1103515245 * nd_GsGetRand_x[i-1] + 12345;

    for(i=0 ; i<310 ; i++) nd_GsGetRand();
}

nd_u32 nd_GsGetRand(
		void)
{
	nd_u32 n;
	n = nd_GsGetRand_x[0];

	if (n == 31) n = 1; else n++;

    nd_GsGetRand_x[0] = n;
	if (n > 3) {
		nd_GsGetRand_x[n] += nd_GsGetRand_x[n-3];
	} else {
		nd_GsGetRand_x[n] += nd_GsGetRand_x[n+31-3];
	}

    return (nd_GsGetRand_x[n]);
}



/**************************************************************************/
