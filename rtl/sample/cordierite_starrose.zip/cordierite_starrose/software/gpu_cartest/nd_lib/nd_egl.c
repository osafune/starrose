/**************************************************************************
	PROCYON �R���\�[�����C�u�����und_Lib�v (PERIDOT LCD Edition)

		�v���~�e�B�u���x���O���t�B�b�N�h���C�o

	2014/04/28	Cineraria/GREENBERYL���Ή��C��
	2014/05/13	PERIDOT LCD���j�b�g�p�C��

 **************************************************************************/

#include "nd_egl.h"
#include "ILI9325.h"


/***** �萔�E�}�N����` ***************************************************/

#define calc_brend(_a,_b,_p)	((((_a)-(_b))*(_p) + ((_b) << 8)) >> 8)

#define nd_FONTX_REPLACE_KANJI			(0x81a0)	// �S�p�̑Ή����镶�����Ȃ��ꍇ�̒u����������(��) 


/***** �\���̒�` *********************************************************/

typedef struct {			/* FONTX�`���A�X�L�[�t�H���g */
    char fontid[6];				// "FONTX2"�Ƃ��������񂪓��� 
    char name[8];				// �t�H���g��(8����) 
    nd_u8 width;				// �t�H���g�̉��� 
    nd_u8 height;				// �t�H���g�̍��� 
    nd_u8 codetype;				// �A�X�L�[�t�H���g��0 
} __attribute__ ((packed)) nd_FONTX_ASCII_header;

typedef struct {			/* FONTX�`�������t�H���g */
    char fontid[6];				// "FONTX2"�Ƃ��������񂪓��� 
    char name[8];				// �t�H���g��(8����) 
    nd_u8 width;				// �t�H���g�̉��� 
    nd_u8 height;				// �t�H���g�̍��� 
    nd_u8 codetype;				// �����t�H���g��1 
    nd_u8 tnum;					// �����R�[�h�e�[�u���̃G���g���� 
    struct {
		nd_u16 begin;			// �̈�̎n�܂�̕����R�[�h 
		nd_u16 end;				// �̈�̏I���̕����R�[�h 
    } codetable[];
} __attribute__ ((packed)) nd_FONTX_KANJI_header;


#if 0
/**************************************************************************
	VGA�R���g���[������
 **************************************************************************/
volatile nd_u32 nd_GsVgaVsyncCount;
volatile nd_u32 nd_GsVgaVsyncFlag;

void nd_GsVgaVsync_isr(void)
{
	nd_u32 status;

#if defined(VGA_BASE)
	status = IORD(np_VGAIO, 0);
	status &= vga_vsyncirq_clear;
	IOWR(np_VGAIO, 0, status);

#elif defined(LCDC_BASE)
	status = IORD(np_LCDCIO, 0);
	status &= lcdc_vsyncirq_clear;
	IOWR(np_LCDCIO, 0, status);

#endif

	if (nd_GsVgaVsyncCount) nd_GsVgaVsyncCount--;
	nd_GsVgaVsyncFlag = 1;
}

void nd_GsVgaVsync_isrenable(void)
{
	nd_u32 status;

#if defined(VGA_BASE)
	status = IORD(np_VGAIO, 0);
	status &= vga_vsyncirq_clear;
	status |= vga_vsyncirq_enable;
	IOWR(np_VGAIO, 0, status);

#elif defined(LCDC_BASE)
	status = IORD(np_LCDCIO, 0);
	status &= lcdc_vsyncirq_clear;
	status |= lcdc_vsyncirq_enable;
	IOWR(np_LCDCIO, 0, status);
#endif
}

void nd_GsVgaVsync_isrdisable(void)
{
	nd_u32 status;

#if defined(VGA_BASE)
	status = IORD(np_VGAIO, 0);
	status &= ~vga_vsyncirq_enable;
	IOWR(np_VGAIO, 0, status);

#elif defined(LCDC_BASE)
	status = IORD(np_LCDCIO, 0);
	status &= ~lcdc_vsyncirq_enable;
	IOWR(np_LCDCIO, 0, status);

#endif
}


void nd_GsVgaScanOn(void)
{
#if defined(VGA_BASE)
	nd_u32 status;

	status = IORD(np_VGAIO, 0);
	status |= vga_scan_enable;
//	status |= (vga_scan_enable | vga_dither_enable);	// DE0��VGA�o�͂��g���ꍇ 
	IOWR(np_VGAIO, 0, status);

#elif defined(LCDC_BASE)
	IOWR(np_LCDCIO, 1, lcdc_scan_enable);

#endif
}

void nd_GsVgaScanOff(void)
{
#if defined(VGA_BASE)
	nd_u32 status;

	status = IORD(np_VGAIO, 0);
	status &= ~vga_scan_enable;
	IOWR(np_VGAIO, 0, status);

#elif defined(LCDC_BASE)
	IOWR(np_LCDCIO, 1, lcdc_scan_disable);

#endif
}

void nd_GsVgaSetBuffer(nd_u32 base)
{
#if defined(VGA_BASE)
	IOWR(np_VGAIO, 1, base & 0x7fffffffUL);		// �A���L���b�V���̈恨�����A�h���X�ϊ� 

#elif defined(LCDC_BASE)
	IOWR(np_LCDCIO, 2, base & 0x7fffffffUL);	// �A���L���b�V���̈恨�����A�h���X�ϊ� 

#endif
}


void nd_GsVgaInit(void)
{
	nd_GsVgaVsync_isrdisable();				// ���ɋN�����������ꍇ�̏��� 
	nd_GsVgaScanOff();

	nd_GsVgaVsyncCount = 0;
	nd_GsVgaVsyncFlag  = 0;
}

void nd_GsVgaWaitVsync(void)
{
#if defined(VGA_BASE)
	nd_u32 vsflag;

	vsflag = IORD(np_VGAIO, 0) & vga_vsyncflag_bitmask;
	while(vsflag ==(IORD(np_VGAIO, 0) & vga_vsyncflag_bitmask)) {};

#elif defined(LCDC_BASE)
	nd_u32 status;

	if ( IORD(np_LCDCIO, 0) & lcdc_vsyncirq_enable ) {	// VSYNC���荞�݂œ��쒆 
		nd_GsVgaVsyncFlag = 0;
		while( !nd_GsVgaVsyncFlag ) {}

	} else {
		status = IORD(np_LCDCIO, 0);
		status &= lcdc_vsyncirq_clear;
		IOWR(np_LCDCIO, 0, status);
		while( !(IORD(np_LCDCIO, 0) & lcdc_vsync_bitmask) ) {}
	}

#endif
}

nd_u32 nd_GsVgaVsync_getcount(void)
{
#if defined(VGA_BASE)
	if ( IORD(np_VGAIO, 0) & vga_vsyncirq_enable ) {	// VSYNC���荞�݂œ��쒆 
		return ( nd_GsVgaVsyncCount );
	} else {
		return ( IORD(np_VGAIO, 2) );
	}

#elif defined(LCDC_BASE)
	if ( IORD(np_LCDCIO, 0) & lcdc_vsyncirq_enable ) {	// VSYNC���荞�݂œ��쒆 
		return ( nd_GsVgaVsyncCount );
	} else {
		return ( IORD(np_LCDCIO, 3) );
	}

#endif
}

void nd_GsVgaVsync_setcount(nd_u32 count)
{
#if defined(VGA_BASE)
	if ( IORD(np_VGAIO, 0) & vga_vsyncirq_enable ) {	// VSYNC���荞�݂œ��쒆 
		nd_GsVgaVsyncCount = count;
	} else {
		IOWR(np_VGAIO, 2, count);
	}

#elif defined(LCDC_BASE)
	if ( IORD(np_LCDCIO, 0) & lcdc_vsyncirq_enable ) {	// VSYNC���荞�݂œ��쒆 
		nd_GsVgaVsyncCount = count;
	} else {
		IOWR(np_LCDCIO, 3, count);
	}

#endif
}


#endif
/**************************************************************************
	�J�����g�y�[�W���Z�b�g
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglPage(nd_u32 viewpage, nd_u32 drawpage, nd_u32 vs)

  �@�\
	�\���y�[�W�ƕ`��y�[�W���Z�b�g����
		viewpage : �\���t���[���o�b�t�@�A�h���X 
		drawpage : �`��t���[���o�b�t�@�A�h���X 
		vs       : �؂�ւ����[�h(0:�����؂芷�� / !0:VSYNC��҂��Đ؂�ւ�) 
*/

nd_u32 nd_GsEglDrawBuffer;

void nd_GsEglPage(
		nd_u32 viewpage, nd_u32 drawpage, nd_u32 vs)
{
//	if (vs) nd_GsVgaWaitVsync();

//	nd_GsVgaSetBuffer(viewpage);
	ILI9325_updatefb((const alt_u16 *)viewpage);
	nd_GsEglDrawBuffer = drawpage;
}



/**************************************************************************
	�J���[���Z�b�g
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglColor(nd_u32 color, nd_u32 bg_color, nd_u32 pastel)

  �@�\
	�A�N�e�B�u�J���[��ݒ肷��
		color    : �O�i�F (0x0000�`0xffff)
		bg_color : �w�i�F (0x0000�`0xffff)
		pastel   : ������ (0�`256)
*/

static nd_u32 nd_color;
static nd_u32 nd_bgcolor;
static nd_u32 nd_pastel;

void nd_GsEglColor(
		nd_u32 color, nd_u32 bg_color, nd_u32 pastel)
{
	nd_color   = color;
	nd_bgcolor = bg_color;
	nd_pastel  = pastel;
}



/**************************************************************************
	�u�q�`�l�ɓ_��`��
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglPset(nd_s32 x, nd_s32 y)

  �@�\
	VRAM��(x,y)��color�Ŏw�肵���_��`�悷��
*/

void nd_GsEglPset(
		nd_s32 x, nd_s32 y)
{
	nd_u16 *p,c;
	nd_s32 r,g,b;

	if( (void *)na_VRAM_base == na_null) return;
	if(nd_pastel == 0) return;

	if((x >= window_xmin)&&(x <= window_xmax) && (y >= window_ymin)&&(y <= window_ymax)) {
		p = (nd_u16 *)( na_VRAM_base + ((draw_base + y)<<na_VRAM_linewidth) + (x<<1));
		c = nd_color;
		if (nd_pastel < 256) {
			r = get_red(*p);
			r = calc_brend(get_red(c),  r, nd_pastel);
			g = get_green(*p);
			g = calc_brend(get_green(c),g, nd_pastel);
			b = get_blue(*p);
			b = calc_brend(get_blue(c), b, nd_pastel);
			c = set_pixel(r,g,b);
		}
		*p = c;
	}
}



/**************************************************************************
	��`�h��Ԃ�
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglBoxfill(nd_s32 x1, nd_s32 y1, nd_s32 x2, nd_s32 y2)

  �@�\
	VRAM��(x1,y1)-(x2,y2)�̋�`����O�i�F�Ŏw�肵���F�œh��Ԃ�
*/

void nd_GsEglBoxfill(
		nd_s32 x1, nd_s32 y1,
		nd_s32 x2, nd_s32 y2)
{
	nd_u16 *p,c;
	nd_s32 r,g,b,x,y;

	if( (void *)na_VRAM_base == na_null) return;
	if(nd_pastel == 0) return;

	if(x1 > x2) { x=x1;  x1=x2;  x2=x; }
	if(y1 > y2) { y=y1;  y1=y2;  y2=y; }

	if(x1 < window_xmin) x1 = window_xmin;
	if(y1 < window_ymin) y1 = window_ymin;
	if(x2 > window_xmax) x2 = window_xmax;
	if(y2 > window_ymax) y2 = window_ymax;

	if(x1 <= x2 && y1 <= y2) {
		for(y=y1 ; y<=y2 ; y++) {
			p = (nd_u16 *)( na_VRAM_base + ((draw_base + y)<<na_VRAM_linewidth) + (x1<<1));
			for(x=x1 ; x<=x2 ; x++) {
				c = nd_color;
				if (nd_pastel < 256) {
					r = get_red(*p);
					r = calc_brend(get_red(c),  r, nd_pastel);
					g = get_green(*p);
					g = calc_brend(get_green(c),g, nd_pastel);
					b = get_blue(*p);
					b = calc_brend(get_blue(c), b, nd_pastel);
					c = set_pixel(r,g,b);
				}
				*p++ = c;
			}
		}
	}
}

void nd_GsEglBox(
		nd_s32 x1, nd_s32 y1,
		nd_s32 x2, nd_s32 y2)
{
	nd_GsEglLine(x1,y1, x2,y1);
	nd_GsEglLine(x1,y2, x2,y2);
	nd_GsEglLine(x2,y1+1, x2,y2-1);
	nd_GsEglLine(x1,y1+1, x1,y2-1);
}



/**************************************************************************
	�~�b�`�F�i�[�A���S���Y���ɂ�鍂���T�[�N���`��
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglCircle(nd_s32 x, nd_s32 y, nd_s32 r)

  �@�\
	VRAM��(x,y)�𒆐S�ɑO�i�F�Ŏw�肵���F�Ŕ��ar�̉~��`�悷��
*/

void nd_GsEglCircle(
		nd_s32 xc, nd_s32 yc,
		nd_s32 r)
{
	nd_s32 x=0,y,d;

	y = r;
	d = 3 - (r << 1);
	while(x < y) {
		nd_GsEglPset(xc+x,yc+y);
		nd_GsEglPset(xc-x,yc+y);
		nd_GsEglPset(xc+x,yc-y);
		nd_GsEglPset(xc-x,yc-y);
		nd_GsEglPset(xc+y,yc+x);
		nd_GsEglPset(xc-y,yc+x);
		nd_GsEglPset(xc+y,yc-x);
		nd_GsEglPset(xc-y,yc-x);

		if(d < 0) {
			d = d + (x << 2) + 6;
		} else {
			d = d + ((x - y)<< 2) + 10;
			y--;
		}
		x++;
	}
	if(x == y) {
		nd_GsEglPset(xc+x,yc+y);
		nd_GsEglPset(xc-x,yc+y);
		nd_GsEglPset(xc+x,yc-y);
		nd_GsEglPset(xc-x,yc-y);
	}
}



/**************************************************************************
	�u���[���n���A���S���Y���ɂ�鍂�����C���`��
 **************************************************************************/
/*
  �`�� 
	viod nd_GsEglLine(nd_s32 x1, nd_s32 y1, nd_s32 x2, nd_s32 y2)

  �@�\
	VRAM��(x1,y1)-(x2,y2)�ɑO�i�F�Ŏw�肵���F�Ń��C����`�悷��
*/

void nd_GsEglLine(
		nd_s32 x1, nd_s32 y1,
		nd_s32 x2 ,nd_s32 y2)
{
	nd_s32 x,y,dx,dy,c1,c2,d,i;

	if((x2 - x1 + y2 - y1) <= 0) {
		x  = x2;  y  = y2;
		x2 = x1;  y2 = y1;
		x1 = x;   y1 = y;
	}

	nd_GsEglPset(x1,y1);

	dx = x2 - x1;  if(dx < 0) dx = -dx;
	dy = y2 - y1;  if(dy < 0) dy = -dy;

	if(dx > dy) {
		c2 = dy << 1;
		d  = c2 - dx;
		c1 = d - dx;
		if(y1 < y2) i = 1; else i = -1;

		y = y1;
		for(x=x1+1 ; x<=x2 ; x++) {
			if(d > 0) {
				d += c1;
				y += i;
			} else {
				d += c2;
			}
			nd_GsEglPset(x,y);
		}
	} else {
		c2 = dx << 1;
		d  = c2 - dy;
		c1 = d - dy;
		if(x1 < x2) i = 1; else i = -1;

		x = x1;
		for(y=y1+1 ; y<=y2 ; y++) {
			if(d > 0) {
				d += c1;
				x += i;
			} else {
				d += c2;
			}
			nd_GsEglPset(x,y);
		}
	}
}



/**************************************************************************
	FONTX�`���t�H���g�`�惉�C�u����
 **************************************************************************/

static nd_u8 *pFONTX_kanji_top;		// �J�����g�̊����t�H���g 
static nd_u8 *pFONTX_ascii_top;		// �J�����g�̃A�X�L�[�����t�H���g 

// SJIS�����R�[�h����r�b�g�}�b�v�̃I�t�Z�b�g���v�Z 
// �Y���r�b�g�}�b�v�������ꍇ�Ana_null��Ԃ� 
static nd_u8 *nd_GsEglFontx_putkanji(nd_s32 kcode,nd_FONTX_KANJI_header *pFont)
{
	nd_s32 i,csize,cb,ce;
	nd_u8 *pKanji;

	csize  = (((nd_s32)pFont->width + 7) >> 3) * (nd_s32)pFont->height;
	pKanji = (nd_u8 *)((nd_u32)pFont + ((nd_s32)pFont->tnum << 2) + 18);

	for(i=0 ; i<pFont->tnum ; i++) {
		cb = pFont->codetable[i].begin;
		ce = pFont->codetable[i].end;
		if (cb <= kcode && kcode <= ce) {
			pKanji += (kcode - cb) * csize;
			i = -1;
			break;

		} else {
			pKanji += (ce - cb + 1) * csize;

		}
	}
	if (i >= 0) pKanji = na_null;

	return pKanji;
}

// ASCII�����R�[�h����r�b�g�}�b�v�̃I�t�Z�b�g���v�Z 
static nd_u8 *nd_GsEglFontx_ascii(nd_s32 acode,nd_FONTX_ASCII_header *pFont)
{
	nd_s32 csize;
	nd_u8 *pAscii;

	csize  = (((nd_s32)pFont->width + 7) >> 3) * (nd_s32)pFont->height;
	pAscii = (nd_u8 *)((nd_u32)pFont + 17 + (acode * csize));

	return pAscii;
}

// �P�����`�� 
//  0x0000�`0x00ff�͈̔͂�ACSII(���p)�A0x8000�`��KANJI(�S�p)�ŕ`�悷�� 
//  �Ԓl�Ƃ��āA�t�H���g�̉�����Ԃ� 
nd_s32 nd_GsEglPutcharFont(
		nd_s32 x,nd_s32 y,
		nd_u16 c)
{
	nd_FONTX_KANJI_header *pFK;
	nd_FONTX_ASCII_header *pFA;

	nd_s32 i,j,w,h;
	nd_u8 *p,cbit = 0;

	if (c <= 0xff) {		// ���p 
		pFA = (nd_FONTX_ASCII_header *)pFONTX_ascii_top;
		if (pFA == na_null) return 0;

		p = nd_GsEglFontx_ascii(c, pFA);
		w = pFA->width;
		h = pFA->height;

	} else {				// �S�p 
		pFK = (nd_FONTX_KANJI_header *)pFONTX_kanji_top;
		if (pFK == na_null) return 0;

		p = nd_GsEglFontx_putkanji(c, pFK);
		if (p == na_null) p = nd_GsEglFontx_putkanji(nd_FONTX_REPLACE_KANJI, pFK);
		w = pFK->width;
		h = pFK->height;

	}

	for(j=0 ; j<h ; j++) {
		for(i=0 ; i<w ; i++,cbit<<=1) {
			if ( !(i & 7) ) cbit = *p++;

			if ( cbit & 0x80 ) {
				nd_GsEglPset(x+i,y+j);
//				nd_GsEglPset(x+i,y+(j<<1));
//				nd_GsEglPset(x+i,y+(j<<1)+1);
			}
		}
	}

	return w;
}

void nd_GsEglPutstrFont(		// ������`�� 
		nd_s32 x,nd_s32 y,
		char *pStr)
{
	nd_u8 *p = (nd_u8 *)pStr;
	nd_u16 c;

	while(*p != '\0') {
		c = *p++;
		if ((0x81 <= c && c <= 0x9f)||(0xe0 <= c && c <= 0xff)) {
			c = (c << 8) | *p++;
		}

		x += nd_GsEglPutcharFont(x, y, c);
		if (x > window_xmax) break;
	}

}

void nd_GsEglSetFont(			// �J�����g�����t�H���g���Z�b�g 
		void *pAscii,
		void *pKanji)
{
	pFONTX_ascii_top = (nd_u8 *)pAscii;
	pFONTX_kanji_top = (nd_u8 *)pKanji;
}



/**************************************************************************
	�W�h�b�g�t�H���g�`�惉�C�u����
 **************************************************************************/
/*
  �`�� 
	void nd_GsEglPutchar(nd_s32 x, nd_s32 y, char *pStr)

  �@�\
	VRAM��(x,y)����O�i�F�Ŏw�肵���F�ƃt�H���g��ASCII�������`�悷��B
	�W�h�b�g�t�H���g�̓J�����g�t�H���g���Ɏw�肵�Ă���
*/
extern const nd_u8 nd_GsEglRomFont[];					// �t�H���g��` 

//static nd_u8 *pFONT8_ascii_top = &nd_GsEglRomFont[0];	// �J�����g��8�h�b�g�����t�H���g 
#define pFONT8_ascii_top		nd_GsEglRomFont

void nd_GsEglPutchar(			// �P�����`�� 
		nd_s32 x,nd_s32 y,
		char s)
{
	nd_s32 i,j,c;

	for(j=0 ; j<8 ; j++) {
		c = *(pFONT8_ascii_top +((s & 0x7f)<< 3)+ j);
		for(i=0 ; i<8 ; i++,c<<=1) {
			if((c & 0x80) != 0) nd_GsEglPset(x+i,y+j);
		}
	}
}

void nd_GsEglPutstr(			// ������`�� 
		nd_s32 x,nd_s32 y,
		char *pStr)
{
	while(*pStr != '\0') {
		nd_GsEglPutchar(x, y, *pStr);
		x += 8;
		pStr++;
	}

}

void nd_GsEglPutdec(			// 10�i���`�� 
		nd_s32 x,nd_s32 y,
		nd_s32 c)
{
	char numstr[14];
	nd_s32 i,num,rem;

	if(c < 0) num = -c; else num = c;
	numstr[12] = '0';
	numstr[13] = '\0';

	i = 12;
	while(num > 0) {
		rem = num % 10;
		num /= 10;
		numstr[i--] = (char)(rem | '0');
	}
	if(c < 0) numstr[i] = '-'; else if(i < 12) i++;

	nd_GsEglPutstr(x,y, &numstr[i]);
}

void nd_GsEglPuthex2(			// 8bit�o�C�i���`�� 
		nd_s32 x, nd_s32 y,
		nd_u32 c)
{
	nd_GsEglPutchar(x, y, (char)((c >> 4)&0x0f));
	nd_GsEglPutchar(x+8, y, (char)(c & 0x0f));
}

void nd_GsEglPuthex8(			// 32bit�o�C�i���`�� 
		nd_s32 x,nd_s32 y,
		nd_u32 c)
{
	nd_s32 i;

	for(i=7 ; i>=0 ; i--,c>>=4) {
		nd_GsEglPutchar(x+(i<<3), y, (char)(c & 0x0f));
	}
}



/**************************************************************************
	�W���W�h�b�g�t�H���g�p�^�[��
 **************************************************************************/

const nd_u8 nd_GsEglRomFont[] = {
	0x1C,0x26,0x63,0x63,0x63,0x32,0x1C,0x00,
	0x0C,0x1C,0x0C,0x0C,0x0C,0x0C,0x3F,0x00,
	0x3E,0x63,0x07,0x1E,0x3C,0x70,0x7F,0x00,
	0x3F,0x06,0x0C,0x1E,0x03,0x63,0x3E,0x00,
	0x0E,0x1E,0x36,0x66,0x7F,0x06,0x06,0x00,
	0x7E,0x60,0x7E,0x03,0x03,0x63,0x3E,0x00,
	0x1E,0x30,0x60,0x7E,0x63,0x63,0x3E,0x00,
	0x7F,0x03,0x06,0x0C,0x18,0x18,0x18,0x00,
	0x3C,0x62,0x72,0x3C,0x4F,0x43,0x3E,0x00,
	0x3E,0x63,0x63,0x3F,0x03,0x06,0x3C,0x00,
	0x1C,0x36,0x63,0x63,0x7F,0x63,0x63,0x00,
	0x7E,0x61,0x61,0x7E,0x61,0x61,0x7E,0x00,
	0x1E,0x33,0x60,0x60,0x60,0x33,0x1E,0x00,
	0x7C,0x66,0x63,0x63,0x63,0x66,0x7C,0x00,
	0x7F,0x60,0x60,0x7E,0x60,0x60,0x7F,0x00,
	0x7F,0x60,0x60,0x7E,0x60,0x60,0x60,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x1C,0x1C,0x1C,0x18,0x18,0x00,0x18,0x00,
	0x36,0x36,0x24,0x00,0x00,0x00,0x00,0x00,
	0x13,0x33,0x7E,0x36,0x37,0x7E,0x24,0x00,
	0x3C,0x6E,0x68,0x3E,0x0B,0x6B,0x3E,0x00,
	0x21,0x52,0x24,0x08,0x12,0x25,0x42,0x00,
	0x18,0x24,0x34,0x38,0x4D,0x46,0x39,0x00,
	0x30,0x30,0x10,0x20,0x00,0x00,0x00,0x00,
	0x04,0x08,0x18,0x10,0x18,0x08,0x04,0x00,
	0x10,0x08,0x0C,0x04,0x0C,0x08,0x10,0x00,
	0x00,0x12,0x0C,0x3F,0x0C,0x12,0x00,0x00,
	0x00,0x08,0x08,0x3E,0x08,0x08,0x00,0x00,
	0x00,0x00,0x00,0x00,0x18,0x18,0x30,0x00,
	0x00,0x00,0x00,0x3E,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,
	0x00,0x02,0x04,0x08,0x10,0x20,0x00,0x00,
	0x1C,0x26,0x63,0x63,0x63,0x32,0x1C,0x00,
	0x0C,0x1C,0x0C,0x0C,0x0C,0x0C,0x3F,0x00,
	0x3E,0x63,0x07,0x1E,0x3C,0x70,0x7F,0x00,
	0x3F,0x06,0x0C,0x1E,0x03,0x63,0x3E,0x00,
	0x0E,0x1E,0x36,0x66,0x7F,0x06,0x06,0x00,
	0x7E,0x60,0x7E,0x03,0x03,0x73,0x3E,0x00,
	0x1E,0x30,0x60,0x7E,0x63,0x63,0x3E,0x00,
	0x7F,0x03,0x06,0x0C,0x18,0x18,0x18,0x00,
	0x3C,0x62,0x72,0x3C,0x4F,0x43,0x3E,0x00,
	0x3E,0x63,0x63,0x3F,0x03,0x06,0x3C,0x00,
	0x00,0x18,0x18,0x00,0x18,0x18,0x00,0x00,
	0x00,0x18,0x18,0x00,0x18,0x18,0x30,0x00,
	0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00,
	0x00,0x00,0x3E,0x00,0x3E,0x00,0x00,0x00,
	0x30,0x18,0x0C,0x06,0x0C,0x18,0x30,0x00,
	0x3E,0x7F,0x63,0x06,0x1C,0x00,0x1C,0x00,
	0x3C,0x42,0x99,0xA1,0xA1,0x99,0x42,0x3C,
	0x1C,0x36,0x63,0x63,0x7F,0x63,0x63,0x00,
	0x7E,0x61,0x61,0x7E,0x61,0x61,0x7E,0x00,
	0x1E,0x33,0x60,0x60,0x60,0x33,0x1E,0x00,
	0x7C,0x66,0x63,0x63,0x63,0x66,0x7C,0x00,
	0x7F,0x60,0x60,0x7E,0x60,0x60,0x7F,0x00,
	0x7F,0x60,0x60,0x7E,0x60,0x60,0x60,0x00,
	0x1F,0x30,0x60,0x67,0x63,0x33,0x1F,0x00,
	0x63,0x63,0x63,0x7F,0x63,0x63,0x63,0x00,
	0x3F,0x0C,0x0C,0x0C,0x0C,0x0C,0x3F,0x00,
	0x03,0x03,0x03,0x03,0x03,0x63,0x3E,0x00,
	0x63,0x66,0x6C,0x78,0x7C,0x66,0x63,0x00,
	0x30,0x30,0x30,0x30,0x30,0x30,0x3F,0x00,
	0x63,0x77,0x7F,0x6B,0x63,0x63,0x63,0x00,
	0x63,0x73,0x7B,0x7F,0x6F,0x67,0x63,0x00,
	0x3E,0x63,0x63,0x63,0x63,0x63,0x3E,0x00,
	0x7E,0x63,0x63,0x63,0x7E,0x60,0x60,0x00,
	0x3E,0x63,0x63,0x63,0x6F,0x66,0x3D,0x00,
	0x7E,0x63,0x63,0x67,0x7C,0x6E,0x67,0x00,
	0x3C,0x66,0x60,0x3E,0x03,0x63,0x3E,0x00,
	0x3F,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x00,
	0x63,0x63,0x63,0x63,0x63,0x63,0x3E,0x00,
	0x63,0x63,0x63,0x77,0x3E,0x1C,0x08,0x00,
	0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00,
	0x63,0x77,0x3E,0x1C,0x3E,0x77,0x63,0x00,
	0x33,0x33,0x33,0x1E,0x0C,0x0C,0x0C,0x00,
	0x7F,0x07,0x0E,0x1C,0x38,0x70,0x7F,0x00,
	0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00,
	0x00,0x10,0x08,0x04,0x02,0x01,0x00,0x00,
	0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00,
	0x00,0x22,0x14,0x08,0x14,0x22,0x00,0x00,
	0x00,0x7F,0x2A,0x2A,0x2A,0x49,0x00,0x00,
	0x40,0x40,0x20,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x3E,0x66,0x66,0x66,0x3B,0x00,
	0x30,0x30,0x30,0x3E,0x33,0x33,0x3E,0x00,
	0x00,0x00,0x1E,0x33,0x30,0x33,0x1E,0x00,
	0x03,0x03,0x03,0x1F,0x33,0x33,0x1F,0x00,
	0x00,0x00,0x1E,0x33,0x3F,0x30,0x1F,0x00,
	0x06,0x0D,0x0C,0x0C,0x1F,0x0C,0x0C,0x00,
	0x02,0x1C,0x32,0x32,0x1C,0x2F,0x23,0x1F,
	0x30,0x30,0x30,0x3E,0x33,0x33,0x33,0x00,
	0x06,0x06,0x00,0x0E,0x06,0x06,0x06,0x00,
	0x06,0x06,0x00,0x06,0x06,0x06,0x26,0x1C,
	0x30,0x30,0x32,0x34,0x38,0x3C,0x36,0x00,
	0x1C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x00,
	0x00,0x76,0x5B,0x5B,0x5B,0x5B,0x5B,0x00,
	0x00,0x3E,0x33,0x33,0x33,0x33,0x33,0x00,
	0x00,0x0E,0x13,0x13,0x13,0x13,0x0E,0x00,
	0x00,0x00,0x3E,0x33,0x33,0x3E,0x30,0x30,
	0x00,0x00,0x1F,0x33,0x33,0x1F,0x03,0x03,
	0x00,0x00,0x1B,0x1E,0x1C,0x18,0x18,0x00,
	0x00,0x00,0x1F,0x38,0x1E,0x07,0x3E,0x00,
	0x0C,0x0C,0x3F,0x0C,0x0C,0x0C,0x06,0x00,
	0x00,0x00,0x33,0x33,0x33,0x33,0x1E,0x00,
	0x00,0x00,0x33,0x33,0x33,0x12,0x0C,0x00,
	0x00,0x00,0x6B,0x6B,0x6A,0x6B,0x36,0x00,
	0x00,0x00,0x33,0x1E,0x0C,0x1E,0x33,0x00,
	0x00,0x1B,0x1B,0x1B,0x0F,0x06,0x0C,0x18,
	0x00,0x00,0x3F,0x06,0x0C,0x18,0x3F,0x00,
	0x00,0x08,0x04,0x04,0x02,0x04,0x04,0x08,
	0x00,0x08,0x08,0x08,0x00,0x08,0x08,0x08,
	0x00,0x10,0x20,0x20,0x40,0x20,0x20,0x10,
	0x00,0x00,0x00,0x30,0x6B,0x06,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};



/**************************************************************************/
