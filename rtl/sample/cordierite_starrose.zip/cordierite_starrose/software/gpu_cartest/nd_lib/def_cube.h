#ifndef __def_cube_h_
#define __def_cube_h_

#include "nd_n3d.h"

typedef struct {
	nd_N3D_header h;
	nd_N3D_objtable t;
	nd_N3D_textable tb;
	nd_N3D_primitive_P4G	p0[5];
	nd_N3D_primitive_P4TG	p1[1];
	nd_N3D_vertex v[8];
	nd_N3D_nvector nv[8];
} n3d_DEF_cube;

typedef const struct {
	nd_TEX_header th;
	nd_u8 texdata[7775];
} n3d_DEF_cube_tex;

extern n3d_DEF_cube cube;
extern n3d_DEF_cube_tex cube_tex;

#endif
