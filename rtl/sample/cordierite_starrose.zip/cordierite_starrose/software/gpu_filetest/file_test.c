/* �t�@�C���V�X�e���e�X�g */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <system.h>
#include <io.h>
#include <sys/alt_cache.h>

#include "mmcfs/mmcfs.h"
#include "nd_lib/nd_egl_peridot.h"
#include "nd_lib/ILI9325.h"
#include "testuty.h"

int loadbmp(const char *bmpname, alt_u16 *pFrameBuffer);

void nd_halt(void)
{
	while(1) {}
}


alt_u32 tpcon_transmit_byte(int command)
{
	alt_u32 dev_tpcon = TOUCHPANEL_BASE;
	alt_u32 rcv_data;

	IOWR(dev_tpcon, 3, (1<<10));					// SSO enable 

	while( !(IORD(dev_tpcon, 2) & (1<<6)) ) {}		// TRDY��҂� 
	IOWR(dev_tpcon, 1, command);
	while( !(IORD(dev_tpcon, 2) & (1<<7)) ) {}		// RRDY��҂� 
	IORD(dev_tpcon, 0);								// �_�~�[���[�h 

	while( !(IORD(dev_tpcon, 2) & (1<<6)) ) {}		// TRDY��҂� 
	IOWR(dev_tpcon, 1, 0x00);
	while( !(IORD(dev_tpcon, 2) & (1<<7)) ) {}		// RRDY��҂� 
	rcv_data = (IORD(dev_tpcon, 0) & 0xff)<< 5;

	while( !(IORD(dev_tpcon, 2) & (1<<6)) ) {}		// TRDY��҂� 
	IOWR(dev_tpcon, 1, 0x00);
	while( !(IORD(dev_tpcon, 2) & (1<<7)) ) {}		// RRDY��҂� 
	rcv_data |= (IORD(dev_tpcon, 0) & 0xff)>> 3;

	IOWR(dev_tpcon, 3, (0<<10));					// SSO disable 

	return rcv_data;
}

int get_touchpoint(int *px, int *py)
{
	alt_u32 dev_tpirq = TOUCHPANEL_IRQ_BASE;
	int i,sum;

	if ( IORD(dev_tpirq, 0) & (1<<0) ) return 0;		// �^�b�`����Ă��Ȃ� (IRQ_n = 1) 

	for(i=0,sum=0 ; i<8 ; i++) {
		sum += tpcon_transmit_byte(
			(1<<7) | (0x5<<4) | (0<<3) | (0<<2) | (0x0<<0)
		);
	}
	*px = (((sum >> 3) - 300) * 240) / (3800 - 300);

	for(i=0,sum=0 ; i<8 ; i++) {
		sum += tpcon_transmit_byte(
			(1<<7) | (0x1<<4) | (0<<3) | (0<<2) | (0x0<<0)
		);
	}
	*py = (((sum >> 3) - 300) * 320) / (3800 - 300);

	return 1;
}



int main(void)
{
	int i,c,x,y;
	alt_u16 *pFrameBuffer;


	// �V�X�e�������� 

	systeminit();
	ILI9325_init();

	mmcfs_setup();


	// �摜��W�J 

//	pFrameBuffer = (alt_u16 *)alt_uncached_malloc(na_VRAM_size);
	pFrameBuffer = (alt_u16 *)(GPU_S3_BASE + 0x81000000UL);

	if (pFrameBuffer != NULL) {
		printf("Framebuffer assignment = 0x%08X\n",(unsigned int)pFrameBuffer);

//		nd_GsVgaSetBuffer((nd_u32)pFrameBuffer);
        nd_GsEglPage((nd_u32)pFrameBuffer,(nd_u32)pFrameBuffer,0);

//		nd_GsVgaScanOn();

		nd_color(nd_COLORGRAY, 0, 256);
		nd_boxfill(0, 0, window_xmax, window_ymax);

        nd_color(nd_COLORWHITE, 0, 256);
		nd_line(0,0, 0,window_ymax);
        nd_color(nd_COLORRED, 0, 256);
		nd_line(window_xmax,0, window_xmax,window_ymax);
        nd_color(nd_COLORLIGHTGREEN, 0, 256);
		nd_line(0,0, window_xmax,0);
        nd_color(nd_COLORBLUE, 0, 256);
		nd_line(0,window_ymax, window_xmax,window_ymax);

		ILI9325_updatefb(pFrameBuffer);
		usleep(1000000);

		loadbmp("mmcfs:/peridot/uzuko3.bmp",pFrameBuffer);

		ILI9325_updatefb(pFrameBuffer);
		usleep(1000000);

	} else {
		printf("[!] Framebuffer not assignment.\r\n");
	}


	while(1) {
		IOWR(LED_BASE, 0, 1);

		if ( get_touchpoint(&x, &y) ) printf("on x = %d, y = %d\n",x,y);

		usleep(50000);

		IOWR(LED_BASE, 0, 0);
		usleep(50000);
	}


	// �I�� 

	printf("done.\n");
    nd_halt();

	return 0;
}
